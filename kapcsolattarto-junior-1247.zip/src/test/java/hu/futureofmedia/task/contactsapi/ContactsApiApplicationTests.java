package hu.futureofmedia.task.contactsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactsApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
